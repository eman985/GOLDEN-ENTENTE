// Golden Ares settings, shared by the visor and base pages.
// Paste the URL of your deployed proxy here (see golden-ares-proxy/README.md). Leave '' to use the on-board engine only.
// This is NOT the Gemini key. The key stays on the proxy server.
window.GOLDEN_ARES_ENDPOINT = '';
