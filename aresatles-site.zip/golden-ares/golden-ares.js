/* GOLDEN ARES - mission assistant for ARES ATLES (visor + base pages)
 *
 * Usage (one block per page, after the page's own script):
 *   GoldenAres.init({ page: 'visor', endpoint: 'https://YOUR-PROXY.run.app/chat', getContext: () => ({ ... }) });
 *
 * - getContext() returns a snapshot of the page's live data. Anything the page cannot supply is left null,
 *   and the assistant is instructed to call it "unavailable" - it must never invent a reading.
 * - The Gemini API key is NOT in this file. The browser talks to your proxy (golden-ares-proxy/), which holds the key.
 * - If the proxy cannot be reached (no endpoint set, comms to Earth down, offline) Golden Ares falls back to a
 *   small LOCAL engine that answers the core questions straight from the same snapshot. Essential functions
 *   keep working without a real-time link.
 */
(function () {
  'use strict';
  const GA = {};
  window.GoldenAres = GA;

  const css = `
  #ga-root{position:fixed;right:18px;bottom:18px;z-index:99999;font-family:ui-monospace,"Cascadia Mono",Consolas,Menlo,monospace;color:#f3e3b0}
  #ga-fab{width:58px;height:58px;border-radius:50%;border:1px solid rgba(255,206,92,.75);background:radial-gradient(circle at 50% 40%,#2a2108,#070605);cursor:pointer;box-shadow:0 0 18px rgba(255,190,60,.35);padding:0;overflow:hidden;display:flex;align-items:center;justify-content:center;pointer-events:auto}
  #ga-fab img{width:44px;height:44px;object-fit:contain}
  #ga-fab:hover{box-shadow:0 0 26px rgba(255,200,80,.6)}
  #ga-panel{display:none;width:min(380px,calc(100vw - 28px));height:min(520px,calc(100vh - 110px));margin-bottom:10px;background:rgba(8,7,5,.93);border:1px solid rgba(255,206,92,.55);border-radius:12px;box-shadow:0 0 30px rgba(255,180,40,.18);flex-direction:column;overflow:hidden;pointer-events:auto;backdrop-filter:blur(6px)}
  #ga-root.open #ga-panel{display:flex}
  #ga-head{display:flex;align-items:center;gap:8px;padding:9px 12px;border-bottom:1px solid rgba(255,206,92,.25);font-size:11px;letter-spacing:.12em;color:#ffd36b;font-weight:700}
  #ga-head .ga-mode{margin-left:auto;font-size:9px;font-weight:400;color:#bfa66a;letter-spacing:.06em}
  #ga-head button{background:none;border:0;color:#bfa66a;cursor:pointer;font-size:16px;line-height:1;padding:0 2px}
  #ga-log{flex:1;overflow-y:auto;padding:10px 12px;display:flex;flex-direction:column;gap:8px;font-size:12px;line-height:1.45}
  .ga-m{max-width:92%;padding:7px 10px;border-radius:9px;white-space:pre-wrap;word-wrap:break-word}
  .ga-u{align-self:flex-end;background:rgba(255,206,92,.14);border:1px solid rgba(255,206,92,.3)}
  .ga-a{align-self:flex-start;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1)}
  .ga-a small{display:block;margin-top:4px;font-size:9px;color:#9c8a5a}
  #ga-chips{display:flex;flex-wrap:wrap;gap:5px;padding:0 12px 8px}
  #ga-chips button{font:inherit;font-size:10px;color:#ffd36b;background:rgba(255,206,92,.08);border:1px solid rgba(255,206,92,.35);border-radius:99px;padding:3px 8px;cursor:pointer}
  #ga-chips button:hover{background:rgba(255,206,92,.2)}
  #ga-form{display:flex;gap:6px;padding:8px 10px;border-top:1px solid rgba(255,206,92,.25)}
  #ga-in{flex:1;min-width:0;font:inherit;font-size:12px;color:#fff3cf;background:rgba(0,0,0,.45);border:1px solid rgba(255,206,92,.35);border-radius:7px;padding:7px 9px;outline:none}
  #ga-in:focus{border-color:#ffd36b}
  #ga-form button{font:inherit;font-size:11px;font-weight:700;color:#1b1405;background:#ffd36b;border:0;border-radius:7px;padding:0 11px;cursor:pointer}
  #ga-form button.ga-mic{background:rgba(255,206,92,.15);color:#ffd36b;border:1px solid rgba(255,206,92,.4)}
  #ga-form button.ga-mic.on{background:#ff5c5c;color:#fff;border-color:#ff5c5c}
  `;

  const fmt = (v, d = 0) => (v === null || v === undefined || Number.isNaN(v)) ? null : Number(v).toFixed(d);
  const num = v => (typeof v === 'number' && isFinite(v)) ? v : null;
  const cardinal = b => ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round((((b % 360) + 360) % 360) / 45) % 8];
  const dist = m => m === null ? null : (m >= 1000 ? (m / 1000).toFixed(2) + ' km' : Math.round(m) + ' m');

  // ---------- rolling history so "has my heart rate changed?" can be answered from data, not guesses ----------
  const hist = [];                         // {t, hr, spo2, rr, core}
  function record() {
    const c = safeCtx(); if (!c) return;
    const v = c.vitals || {};
    hist.push({ t: Date.now(), hr: num(v.heartRateBpm), spo2: num(v.spo2Pct), rr: num(v.respRateBrMin), core: num(v.coreTempC) });
    while (hist.length > 180) hist.shift();   // 15 minutes at 5 s
  }
  function trend(key) {
    const pts = hist.filter(h => h[key] !== null);
    if (pts.length < 3) return null;
    const now = pts[pts.length - 1];
    const ref = pts.find(p => now.t - p.t <= 65000) || pts[0];
    const vals = pts.map(p => p[key]);
    return {
      now: now[key], approxSecondsAgo: Math.round((now.t - ref.t) / 1000), then: ref[key],
      change: +(now[key] - ref[key]).toFixed(2),
      windowMin: Math.min(...vals), windowMax: Math.max(...vals), windowSeconds: Math.round((now.t - pts[0].t) / 1000)
    };
  }
  function safeCtx() { try { return GA.cfg.getContext(); } catch (e) { return null; } }
  function snapshot() {
    const c = safeCtx() || {};
    c.recentTrends = { heartRate: trend('hr'), spo2: trend('spo2'), respRate: trend('rr'), coreTemp: trend('core') };
    return c;
  }

  // ---------- LOCAL fallback engine: answers from the snapshot only ----------
  function localAnswer(q, c) {
    q = q.toLowerCase();
    const P = c.position || {}, H = c.habitat || {}, V = c.vitals || {}, S = c.suit || {}, E = c.environment || {}, O = c.observations || {}, R = c.route || {};
    const crit = [];
    if (S.oxygenMinutesLeft !== null && S.oxygenMinutesLeft !== undefined && S.oxygenMinutesLeft < 45) crit.push(`Oxygen margin is low: about ${Math.round(S.oxygenMinutesLeft)} minutes at the current rate.`);
    if (num(S.pressureKpa) !== null && S.pressureKpa < 25) crit.push(`Suit pressure is low at ${fmt(S.pressureKpa, 1)} kPa.`);
    if (V.alertState && V.alertState !== 'GREEN') crit.push(`Biomonitor state is ${V.alertState}${V.alertReasons && V.alertReasons.length ? ' (' + V.alertReasons.join('; ') + ')' : ''}.`);
    const lead = crit.length ? crit.join(' ') + ' ' : '';
    const has = (...w) => w.some(x => q.includes(x));

    if (has('where am i', 'where are we', 'my location', 'position', 'coordinates', 'located', 'location', 'lat', 'gps'))
      return num(P.lat) === null ? 'I do not have a position fix right now.' :
        `You are at ${fmt(P.lat, 5)}° N, ${fmt(P.lon, 5)}° E` + (num(P.elevationM) !== null ? `, elevation ${Math.round(P.elevationM)} m` : '') +
        (num(H.distanceM) !== null ? `. The habitat is ${dist(H.distanceM)} away, bearing ${Math.round(H.bearingDeg)}° ${cardinal(H.bearingDeg)}.` : '.') + ' Position is simulated, not a GPS fix.';
    if (has('how far', 'habitat', 'hab ', 'base', 'distance', 'route', 'way back', 'return', 'go home', 'get back', 'safest', 'rtb', 'home')) {
      if (num(H.distanceM) === null) return 'I have no distance to the habitat right now.';
      let a = `${lead}The habitat is ${dist(H.distanceM)} away, bearing ${Math.round(H.bearingDeg)}° ${cardinal(H.bearingDeg)}.`;
      if (num(H.routeDistanceM) !== null) a += ` The planned route is ${dist(H.routeDistanceM)}` + (R.avoidedHazards ? ` and avoids ${R.avoidedHazards} hazard cells` : '') + '.';
      else if (num(H.trailBackM) !== null) a += ` Retracing your own trail is ${dist(H.trailBackM)}, which is known-safe ground.`;
      if (num(S.oxygenMinutesLeft) !== null && num(H.walkMinutes) !== null) a += ` Walking back takes about ${Math.round(H.walkMinutes)} minutes against ${Math.round(S.oxygenMinutesLeft)} minutes of oxygen.`;
      return a;
    }
    if (has('heart', 'pulse', 'bpm', 'changed', 'hr ')) {
      const t = c.recentTrends && c.recentTrends.heartRate;
      if (num(V.heartRateBpm) === null) return 'No heart rate is being reported.';
      let a = `${lead}Heart rate is ${Math.round(V.heartRateBpm)} bpm` + (num(V.heartRateBaselineRestBpm) !== null ? ` against a resting baseline of ${V.heartRateBaselineRestBpm}` : '') + '.';
      if (t) a += Math.abs(t.change) < 4 ? ` It has been steady over the last ${t.windowSeconds} seconds (range ${Math.round(t.windowMin)} to ${Math.round(t.windowMax)}).` : ` It has ${t.change > 0 ? 'risen' : 'fallen'} by ${Math.abs(Math.round(t.change))} bpm over about ${t.approxSecondsAgo} seconds.`;
      else a += ' I have not collected enough history yet to describe a change.';
      return a;
    }
    if (has('health', 'vital', 'readings', 'body', 'blood', 'spo2', 'saturation', 'temperature', 'how am i', 'am i ok', 'am i okay', 'doing', 'breath', 'respir', 'status')) {
      const parts = [];
      if (num(V.heartRateBpm) !== null) parts.push(`heart rate ${Math.round(V.heartRateBpm)} bpm`);
      if (num(V.spo2Pct) !== null) parts.push(`SpO2 ${fmt(V.spo2Pct, 1)}%`);
      if (num(V.respRateBrMin) !== null) parts.push(`respiration ${Math.round(V.respRateBrMin)} per minute`);
      if (V.bloodPressure) parts.push(`blood pressure ${V.bloodPressure}`);
      if (num(V.coreTempC) !== null) parts.push(`core temperature ${fmt(V.coreTempC, 1)}°C`);
      if (!parts.length) return 'No physiological readings are available.';
      const na = ['SpO2', 'respiration', 'blood pressure'].filter((n, i) => [V.spo2Pct, V.respRateBrMin, V.bloodPressure][i] == null);
      return `${lead}Current readings: ${parts.join(', ')}. State: ${V.alertState || 'not reported'}.` + (na.length ? ` Not reported on this view: ${na.join(', ')}.` : '') + ' These are modelled values, and I do not diagnose; I only flag changes.';
    }
    if (has('suit', 'o2', 'oxygen', 'air left', 'pressure', 'co2', 'carbon', 'battery', 'power', 'scrubber', 'coolant', 'water', 'leak')) {
      const parts = [];
      if (num(S.oxygenPct) !== null) parts.push(`oxygen ${fmt(S.oxygenPct, 1)}%` + (num(S.oxygenMinutesLeft) !== null ? ` (about ${Math.round(S.oxygenMinutesLeft)} min)` : ''));
      if (num(S.pressureKpa) !== null) parts.push(`pressure ${fmt(S.pressureKpa, 1)} kPa`);
      if (num(S.batteryPct) !== null) parts.push(`battery ${fmt(S.batteryPct, 1)}%`);
      if (num(S.co2ScrubberPct) !== null) parts.push(`CO2 scrubber ${fmt(S.co2ScrubberPct, 0)}%`);
      if (num(S.coolantL) !== null) parts.push(`coolant ${fmt(S.coolantL, 1)} L`);
      let a = `${lead}Suit: ${parts.join(', ')}.`;
      if (num(S.co2PartialPressureKpa) === null) a += ' A CO2 concentration is not reported by this simulation, so I cannot state one.';
      return a;
    }
    if (has('environment', 'weather', 'wind', 'dust', 'storm', 'radiation', 'outside', 'visib', 'concern', 'danger', 'safe', 'alert', 'warning', 'hazard')) {
      const parts = [];
      if (num(E.airTempC) !== null) parts.push(`air ${Math.round(E.airTempC)}°C`);
      if (num(E.pressurePa) !== null) parts.push(`pressure ${Math.round(E.pressurePa)} Pa`);
      if (num(E.windMs) !== null) parts.push(`wind ${fmt(E.windMs, 1)} m/s`);
      if (num(E.dustOpacityTau) !== null) parts.push(`dust opacity ${fmt(E.dustOpacityTau, 2)}`);
      if (num(E.visibilityKm) !== null) parts.push(`visibility ${fmt(E.visibilityKm, 1)} km`);
      if (num(E.doseRateUsvH) !== null) parts.push(`radiation ${Math.round(E.doseRateUsvH)} µSv/h`);
      const al = (c.alerts || []).filter(a => a.level !== 'ok');
      return `${lead}Environment (modelled): ${parts.join(', ') || 'no data'}. ` + (al.length ? 'Active alerts: ' + al.map(a => a.title).join('; ') + '.' : 'No environmental alerts are active.');
    }
    if (has('observation', 'sample', 'collected', 'summar', 'photo', 'science', 'rock', 'geolog', 'found')) {
      const bits = [];
      if (num(O.samplesCollected) !== null) bits.push(`${O.samplesCollected} sample${O.samplesCollected === 1 ? '' : 's'} sealed`);
      if (O.sampledTargets && O.sampledTargets.length) bits.push('from ' + O.sampledTargets.join(', '));
      if (num(O.photos) !== null) bits.push(`${O.photos} image${O.photos === 1 ? '' : 's'} taken`);
      return bits.length ? `So far: ${bits.join(', ')}.` : 'No observations have been logged yet.';
    }
    return 'I am running on the on-board engine only' + (GA.gemini === 'down' ? ' (the Gemini link did not respond)' : ' (Gemini is not connected on this site yet)') + ', so I can only answer set mission questions: position, distance and route to the habitat, vitals and trends, suit readings, environment, observations. Try one of the buttons below.';
  }

  // ---------- UI ----------
  function build() {
    const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    const root = document.createElement('div'); root.id = 'ga-root';
    root.innerHTML = `
      <div id="ga-panel" role="dialog" aria-label="Golden Ares assistant">
        <div id="ga-head"><img src="${GA.cfg.logo}" alt="" width="20" height="20" style="object-fit:contain">GOLDEN ARES<span class="ga-mode" id="ga-mode">LOCAL</span><button id="ga-x" aria-label="Close">&times;</button></div>
        <div id="ga-log" aria-live="polite"></div>
        <div id="ga-chips"></div>
        <form id="ga-form" autocomplete="off"><input id="ga-in" placeholder="Ask Golden Ares..." maxlength="300"><button type="button" class="ga-mic" id="ga-mic" title="Speak">MIC</button><button type="submit">SEND</button></form>
      </div>
      <button id="ga-fab" aria-label="Open Golden Ares"><img src="${GA.cfg.logo}" alt="Golden Ares"></button>`;
    if (GA.cfg.side === 'left') { root.style.right = 'auto'; root.style.left = '18px'; }
    document.body.appendChild(root);
    // keep keystrokes in the chat box from driving the visor (WASD etc.)
    ['keydown', 'keyup', 'keypress'].forEach(ev => root.addEventListener(ev, e => e.stopPropagation()));
    ['pointerdown', 'mousedown', 'wheel', 'dblclick', 'click'].forEach(ev => root.addEventListener(ev, e => e.stopPropagation()));

    const $ = s => root.querySelector(s);
    const log = $('#ga-log');
    const add = (txt, cls, note) => { const d = document.createElement('div'); d.className = 'ga-m ' + cls; d.textContent = txt; if (note) { const s = document.createElement('small'); s.textContent = note; d.appendChild(s); } log.appendChild(d); log.scrollTop = log.scrollHeight; return d; };
    const turns = [];

    GA.cfg.chips.forEach(c => { const b = document.createElement('button'); b.type = 'button'; b.textContent = c; b.onclick = () => ask(c); $('#ga-chips').appendChild(b); });
    $('#ga-fab').onclick = () => { root.classList.toggle('open'); if (root.classList.contains('open')) { $('#ga-in').focus(); if (!log.children.length) add('Golden Ares online. Ask about your position, vitals, suit, environment or route home.', 'ga-a'); } };
    $('#ga-x').onclick = () => root.classList.remove('open');
    $('#ga-form').onsubmit = e => { e.preventDefault(); const v = $('#ga-in').value.trim(); if (v) { $('#ga-in').value = ''; ask(v); } };

    function setMode(m) { $('#ga-mode').textContent = m; }
    setMode(GA.cfg.endpoint ? 'ONLINE' : 'LOCAL');

    async function ask(q) {
      add(q, 'ga-u');
      const waiting = add('...', 'ga-a');
      const ctx = snapshot();
      let answer = null, via = 'local';
      if (GA.cfg.endpoint && ctx.comms && ctx.comms.linkUp === false) {
        via = 'local'; // simulated comms blackout: stay on the on-board engine
      } else if (GA.cfg.endpoint) {
        try {
          const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 15000);
          const r = await fetch(GA.cfg.endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctl.signal,
            body: JSON.stringify({ question: q, page: GA.cfg.page, context: ctx, history: turns.slice(-6) }) });
          clearTimeout(to);
          if (!r.ok) throw new Error('HTTP ' + r.status);
          answer = (await r.json()).answer; via = 'gemini'; GA.gemini = 'up';
        } catch (e) { answer = null; GA.gemini = 'down'; console.warn('Golden Ares: Gemini request failed', e); }
      }
      if (!answer) answer = localAnswer(q, ctx);
      setMode(via === 'gemini' ? 'ONLINE' : 'LOCAL');
      waiting.remove();
      add(answer, 'ga-a', via === 'gemini' ? 'Gemini, from live telemetry' : 'on-board engine, from live telemetry');
      turns.push({ role: 'user', text: q }, { role: 'model', text: answer });
      if (GA.cfg.speak && 'speechSynthesis' in window) { try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(answer); u.rate = 1.02; speechSynthesis.speak(u); } catch (e) { } }
    }
    GA.ask = ask;

    // voice input (Chrome/Edge/Safari)
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const mic = $('#ga-mic');
    if (!SR) mic.style.display = 'none';
    else {
      let rec = null;
      mic.onclick = () => {
        if (rec) { rec.stop(); return; }
        rec = new SR(); rec.lang = 'en-GB'; rec.interimResults = false;
        rec.onresult = e => { const t = e.results[0][0].transcript; $('#ga-in').value = ''; ask(t); };
        rec.onend = () => { rec = null; mic.classList.remove('on'); }; rec.onerror = () => { };
        mic.classList.add('on'); rec.start();
      };
    }
  }

  GA.init = function (cfg) {
    GA.cfg = Object.assign({
      page: 'unknown', endpoint: '', side: 'right', logo: '../assets/logo.jpg', speak: false,
      chips: ['Where am I?', 'How far is the habitat?', 'Health summary', 'Has my heart rate changed?', 'Suit status', 'Any environmental concerns?', 'Summarise my observations'],
      getContext: () => ({})
    }, cfg || {});
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
    setInterval(record, 5000);
  };
})();
