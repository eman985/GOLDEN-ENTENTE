#!/usr/bin/env python3
"""
prepare_terrain.py
==================
Turns your two cropped HiRISE GeoTIFFs of the Jezero sector (18.42-18.47 N, 77.42-77.48 E)
into the web-ready files that mars-visor-local.html loads.

    python prepare_terrain.py sector_ortho.tif sector_dtm.tif

Inputs (made with gdal_translate -projwin, see the instructions):
    sector_ortho.tif   HiRISE orthoimage crop, 0.25 m/pixel, 8-bit grayscale
    sector_dtm.tif     HiRISE DTM crop (elevation in metres), about 1 m/pixel

Output folder (default ./terrain), which must sit next to mars-visor-local.html:
    meta.json          sizes, tile grid, height range
    height.u16         elevation grid, 16-bit, row 0 = north edge
    lo/R_C.jpg         small (1 m/px) version of every 256 m tile
    hi/R_C.jpg         full-resolution (25 cm/px) tile, loaded only when you are close

Requires:  pip install pillow numpy
"""
import argparse, json, math, os, sys
import numpy as np
from PIL import Image

Image.MAX_IMAGE_PIXELS = None            # the full-res crop is ~170 megapixels

MPD = 59275.0                            # metres per degree on Mars (R = 3396.19 km)
LAT_REF = 18.4446                        # must match LAT0 in the viewer


def stretch_lut(arr, lo_pct=2.0, hi_pct=98.0):
    """Contrast stretch for 8-bit imagery, via a lookup table (fast, low memory)."""
    hist = np.bincount(arr.ravel(), minlength=256).astype(np.float64)
    hist[0] = 0                          # 0 = no data in the mosaic; ignore it
    total = hist.sum()
    if total == 0:
        return np.arange(256, dtype=np.uint8)
    cdf = np.cumsum(hist) / total
    lo = int(np.searchsorted(cdf, lo_pct / 100.0))
    hi = int(np.searchsorted(cdf, hi_pct / 100.0))
    hi = max(hi, lo + 1)
    lut = np.clip((np.arange(256) - lo) / (hi - lo), 0, 1) * 255.0
    lut[0] = 0
    return lut.astype(np.uint8)


def load_ortho(path):
    im = Image.open(path)
    print(f"  ortho: {im.size[0]} x {im.size[1]} px, mode {im.mode}")
    a = np.asarray(im)
    if a.ndim == 3:
        a = a[..., 0]
    if a.dtype != np.uint8:              # rare: 16-bit or float imagery -> scale to 8-bit
        a = a.astype(np.float32)
        valid = a[a > 0]
        lo, hi = (np.percentile(valid, 1), np.percentile(valid, 99)) if valid.size else (0, 1)
        a = np.clip((a - lo) / max(hi - lo, 1e-6), 0, 1) * 254 + 1
        a = a.astype(np.uint8)
    return a


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("ortho")
    ap.add_argument("dtm")
    ap.add_argument("--out", default="terrain")
    ap.add_argument("--tile", type=int, default=1024, help="tile size in ortho pixels (default 1024 = 256 m)")
    ap.add_argument("--hstep", type=float, default=2.0, help="heightmap spacing in metres (default 2)")
    ap.add_argument("--lat", nargs=2, type=float, default=[18.42, 18.47])
    ap.add_argument("--lon", nargs=2, type=float, default=[77.42, 77.48])
    ap.add_argument("--no-stretch", action="store_true", help="keep the original image contrast")
    args = ap.parse_args()

    os.makedirs(os.path.join(args.out, "hi"), exist_ok=True)
    os.makedirs(os.path.join(args.out, "lo"), exist_ok=True)

    width_m = (args.lon[1] - args.lon[0]) * MPD * math.cos(math.radians(LAT_REF))
    height_m = (args.lat[1] - args.lat[0]) * MPD

    # ---------- imagery ----------
    print("Reading orthoimage ...")
    a = load_ortho(args.ortho)
    H, W = a.shape
    px_aspect = W / H
    want_aspect = (args.lon[1] - args.lon[0]) / (args.lat[1] - args.lat[0])
    if abs(px_aspect / want_aspect - 1) > 0.05:
        print(f"  WARNING: image is {W}x{H} (aspect {px_aspect:.2f}) but the sector should be about "
              f"{want_aspect:.2f}. The crop may not match 18.42-18.47 N / 77.42-77.48 E.", file=sys.stderr)
    if not args.no_stretch:
        a = stretch_lut(a)[a]

    tile = args.tile
    cols, rows = math.ceil(W / tile), math.ceil(H / tile)
    print(f"Cutting {rows} x {cols} = {rows * cols} tiles ...")
    hi_bytes = 0
    for r in range(rows):
        for c in range(cols):
            x0, y0 = c * tile, r * tile
            x1, y1 = min(x0 + tile, W), min(y0 + tile, H)
            t = Image.fromarray(a[y0:y1, x0:x1])
            hp = os.path.join(args.out, "hi", f"{r}_{c}.jpg")
            t.save(hp, quality=82, optimize=True)
            hi_bytes += os.path.getsize(hp)
            lo = t.resize((max(1, round((x1 - x0) / 4)), max(1, round((y1 - y0) / 4))), Image.BOX)
            lo.save(os.path.join(args.out, "lo", f"{r}_{c}.jpg"), quality=82)
        print(f"  row {r + 1}/{rows}", end="\r")
    print()
    del a

    # ---------- elevation ----------
    print("Reading DTM ...")
    d = Image.open(args.dtm)
    print(f"  dtm: {d.size[0]} x {d.size[1]} px, mode {d.mode}")
    z = np.asarray(d.convert("F"), dtype=np.float32).copy()
    bad = ~np.isfinite(z) | (np.abs(z) > 1e6)
    if bad.any():
        frac = bad.mean() * 100
        print(f"  {frac:.2f}% of DTM pixels are no-data; filling them with the median")
        z[bad] = np.median(z[~bad]) if (~bad).any() else 0.0

    nx = int(round(width_m / args.hstep)) + 1
    ny = int(round(height_m / args.hstep)) + 1
    g = np.asarray(Image.fromarray(z).resize((nx, ny), Image.BILINEAR), dtype=np.float32)
    hmin, hmax = float(g.min()), float(g.max())
    u16 = np.round((g - hmin) / max(hmax - hmin, 1e-6) * 65535).astype("<u2")
    u16.tofile(os.path.join(args.out, "height.u16"))
    print(f"  heightmap {nx} x {ny}, elevation {hmin:.1f} .. {hmax:.1f} m (relief {hmax - hmin:.0f} m)")

    meta = {
        "version": 1,
        "bounds": {"lat": args.lat, "lon": args.lon},
        "widthM": width_m, "heightM": height_m,
        "ortho": {"widthPx": W, "heightPx": H, "tile": tile, "rows": rows, "cols": cols},
        "height": {"file": "height.u16", "nx": nx, "ny": ny, "hmin": hmin, "hmax": hmax},
    }
    with open(os.path.join(args.out, "meta.json"), "w") as f:
        json.dump(meta, f, indent=1)
    print(f"Done. {rows * cols} tiles ({hi_bytes / 1e6:.0f} MB full-res), height grid {nx * ny * 2 / 1e6:.1f} MB.")
    print(f"Put the '{args.out}' folder next to mars-visor-local.html and open that page from a local server.")


if __name__ == "__main__":
    main()
