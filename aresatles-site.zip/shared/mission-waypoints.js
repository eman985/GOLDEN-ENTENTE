/* Mission waypoints shared by the Base (telemetry) page and the Visor.
   Edit them here once and both pages follow. Positions are inside the sector 18.42-18.47 N, 77.42-77.48 E.
   zone/sci only affect the visor's science readouts (zone = rock type shown, sci = science priority 0..1). */
window.MISSION_WAYPOINTS = [
  { id: 'wp-1', name: 'Three Forks Delta Scarp',    lat: 18.4518, lng: 77.4415, zone: 'delta',  sci: 0.95 },
  { id: 'wp-2', name: 'Séítah Fractured Bedrock',   lat: 18.4410, lng: 77.4435, zone: 'seitah', sci: 0.90 },
  { id: 'wp-3', name: 'Kodiak Remnant Mesa Butte',  lat: 18.4368, lng: 77.4365, zone: 'delta',  sci: 0.85 },
  { id: 'wp-4', name: 'Belva Impact Crater Rim',    lat: 18.4555, lng: 77.4472, zone: 'maaz',   sci: 0.80 }
];
